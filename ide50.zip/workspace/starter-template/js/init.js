(function($){
  $(function(){

    $('.sidenav').sidenav();
    $(".dropdown-trigger").dropdown();
    $('.carousel').carousel({
      indicators: true
    });
  });

})(jQuery); // end of jQuery name space
